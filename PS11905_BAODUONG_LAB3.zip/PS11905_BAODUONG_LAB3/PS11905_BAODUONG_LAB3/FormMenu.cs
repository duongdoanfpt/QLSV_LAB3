﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PS11905_BAODUONG_LAB3
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void hinhBai1_Click(object sender, EventArgs e)
        {
            Visible = false;
            ShowInTaskbar = false;
            Bai1 frm1 = new Bai1();
            frm1.Activate();
            frm1.Show();
        }

        private void FormMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void hinhBai2_Click(object sender, EventArgs e)
        {
            Visible = false;
            ShowInTaskbar = false;
            BAI2 frm2 = new BAI2();
            frm2.Activate();
            frm2.Show();
        }
    }
}
