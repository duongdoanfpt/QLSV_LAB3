﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PS11905_BAODUONG_LAB3
{
    public partial class Bai1 : Form
    {
        public Bai1()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void Bai1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btLuu_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KMNS09Q;Initial Catalog=QLHocSinh;Integrated Security=True"))
            {
                con.Open();
                try
                {
                    // Query insert
                    string query = "insert into HocSinh(MaHS,TenHS,NgaySinh,DiaChi,DTB,MaLop)" + "values(@MaHS,@TenHS,@NgaySinh,@DiaChi,@DTB,@MaLop)";
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = query;

                    // Tạo một đối tượng Parameter.
                    cmd.Parameters.Add("@MaHS", SqlDbType.VarChar).Value = txtMaHS.Text;
                    cmd.Parameters.Add("@TenHS", SqlDbType.NVarChar).Value = txtTenHS.Text;
                    cmd.Parameters.Add("@NgaySinh", SqlDbType.Date).Value = dateTimeNSinh.Value.ToString();
                    cmd.Parameters.Add("@DiaChi", SqlDbType.VarChar).Value = txtDChi.Text;
                    cmd.Parameters.Add("@DTB", SqlDbType.Float).Value = txtDTB.Text;
                    cmd.Parameters.Add("@MaLop", SqlDbType.VarChar).Value = txtLop.Text;

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm thành công");
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }

                //// câu lệnh Query
                //string query = "insert into HocSinh(MaHS,TenHS,NgaySinh,DiaChi,DTB,MaLop) values(";query += "','" + txtMaHS.Text + "',N'" + txtTenHS.Text + "','" + dateTimeNSinh.Value.Date + "','" + txtDChi.Text + "','" + txtDTB.Text + "','" + txtLop.Text + "')";

                ////Thực thi câu lệnh SQL sử dụng đối tượng Command
                //SqlCommand cmd = new SqlCommand(query, con);
                //cmd.ExecuteNonQuery();

              


                
            }
        }

        private void Bai1_Load(object sender, EventArgs e)
        {
            dateTimeNSinh.Format = DateTimePickerFormat.Custom;
            dateTimeNSinh.CustomFormat = "dd/MM/yyyy";
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            txtMaHS.Text = "";
            txtTenHS.Text = "";
            txtLop.Text = "";
            txtDChi.Text = "";
            txtDTB.Text = "";
        }
    }
}
