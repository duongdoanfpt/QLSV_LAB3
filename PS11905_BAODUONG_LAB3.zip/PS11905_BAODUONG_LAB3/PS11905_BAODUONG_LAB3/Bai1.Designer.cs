﻿namespace PS11905_BAODUONG_LAB3
{
    partial class Bai1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbMaHS = new System.Windows.Forms.Label();
            this.txtMaHS = new System.Windows.Forms.TextBox();
            this.txtTenHS = new System.Windows.Forms.TextBox();
            this.lbTenHS = new System.Windows.Forms.Label();
            this.lbNgaySinh = new System.Windows.Forms.Label();
            this.txtDChi = new System.Windows.Forms.TextBox();
            this.lbDiaChi = new System.Windows.Forms.Label();
            this.lbLop = new System.Windows.Forms.Label();
            this.txtDTB = new System.Windows.Forms.TextBox();
            this.lbDiemTB = new System.Windows.Forms.Label();
            this.dateTimeNSinh = new System.Windows.Forms.DateTimePicker();
            this.btThoat = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.btLuu = new System.Windows.Forms.Button();
            this.txtLop = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(184, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(429, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "DANH SÁCH HỌC SINH";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimeNSinh);
            this.groupBox1.Controls.Add(this.txtDTB);
            this.groupBox1.Controls.Add(this.txtLop);
            this.groupBox1.Controls.Add(this.lbDiemTB);
            this.groupBox1.Controls.Add(this.lbLop);
            this.groupBox1.Controls.Add(this.txtDChi);
            this.groupBox1.Controls.Add(this.lbDiaChi);
            this.groupBox1.Controls.Add(this.lbNgaySinh);
            this.groupBox1.Controls.Add(this.txtTenHS);
            this.groupBox1.Controls.Add(this.lbTenHS);
            this.groupBox1.Controls.Add(this.txtMaHS);
            this.groupBox1.Controls.Add(this.lbMaHS);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Lime;
            this.groupBox1.Location = new System.Drawing.Point(34, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(755, 355);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin học sinh";
            // 
            // lbMaHS
            // 
            this.lbMaHS.AutoSize = true;
            this.lbMaHS.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaHS.ForeColor = System.Drawing.Color.White;
            this.lbMaHS.Location = new System.Drawing.Point(89, 57);
            this.lbMaHS.Name = "lbMaHS";
            this.lbMaHS.Size = new System.Drawing.Size(122, 24);
            this.lbMaHS.TabIndex = 0;
            this.lbMaHS.Text = "Mã học sinh ";
            // 
            // txtMaHS
            // 
            this.txtMaHS.Location = new System.Drawing.Point(249, 49);
            this.txtMaHS.Name = "txtMaHS";
            this.txtMaHS.Size = new System.Drawing.Size(420, 32);
            this.txtMaHS.TabIndex = 1;
            // 
            // txtTenHS
            // 
            this.txtTenHS.Location = new System.Drawing.Point(249, 96);
            this.txtTenHS.Name = "txtTenHS";
            this.txtTenHS.Size = new System.Drawing.Size(420, 32);
            this.txtTenHS.TabIndex = 3;
            // 
            // lbTenHS
            // 
            this.lbTenHS.AutoSize = true;
            this.lbTenHS.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenHS.ForeColor = System.Drawing.Color.White;
            this.lbTenHS.Location = new System.Drawing.Point(89, 104);
            this.lbTenHS.Name = "lbTenHS";
            this.lbTenHS.Size = new System.Drawing.Size(126, 24);
            this.lbTenHS.TabIndex = 2;
            this.lbTenHS.Text = "Tên học sinh ";
            // 
            // lbNgaySinh
            // 
            this.lbNgaySinh.AutoSize = true;
            this.lbNgaySinh.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgaySinh.ForeColor = System.Drawing.Color.White;
            this.lbNgaySinh.Location = new System.Drawing.Point(89, 153);
            this.lbNgaySinh.Name = "lbNgaySinh";
            this.lbNgaySinh.Size = new System.Drawing.Size(101, 24);
            this.lbNgaySinh.TabIndex = 4;
            this.lbNgaySinh.Text = "Ngày Sinh";
            // 
            // txtDChi
            // 
            this.txtDChi.Location = new System.Drawing.Point(249, 192);
            this.txtDChi.Name = "txtDChi";
            this.txtDChi.Size = new System.Drawing.Size(420, 32);
            this.txtDChi.TabIndex = 7;
            // 
            // lbDiaChi
            // 
            this.lbDiaChi.AutoSize = true;
            this.lbDiaChi.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiaChi.ForeColor = System.Drawing.Color.White;
            this.lbDiaChi.Location = new System.Drawing.Point(89, 200);
            this.lbDiaChi.Name = "lbDiaChi";
            this.lbDiaChi.Size = new System.Drawing.Size(72, 24);
            this.lbDiaChi.TabIndex = 6;
            this.lbDiaChi.Text = "Địa chỉ";
            // 
            // lbLop
            // 
            this.lbLop.AutoSize = true;
            this.lbLop.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLop.ForeColor = System.Drawing.Color.White;
            this.lbLop.Location = new System.Drawing.Point(89, 252);
            this.lbLop.Name = "lbLop";
            this.lbLop.Size = new System.Drawing.Size(47, 24);
            this.lbLop.TabIndex = 8;
            this.lbLop.Text = "Lớp";
            // 
            // txtDTB
            // 
            this.txtDTB.Location = new System.Drawing.Point(249, 291);
            this.txtDTB.Name = "txtDTB";
            this.txtDTB.Size = new System.Drawing.Size(420, 32);
            this.txtDTB.TabIndex = 9;
            // 
            // lbDiemTB
            // 
            this.lbDiemTB.AutoSize = true;
            this.lbDiemTB.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiemTB.ForeColor = System.Drawing.Color.White;
            this.lbDiemTB.Location = new System.Drawing.Point(89, 299);
            this.lbDiemTB.Name = "lbDiemTB";
            this.lbDiemTB.Size = new System.Drawing.Size(90, 24);
            this.lbDiemTB.TabIndex = 8;
            this.lbDiemTB.Text = "Điểm TB";
            // 
            // dateTimeNSinh
            // 
            this.dateTimeNSinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeNSinh.Location = new System.Drawing.Point(249, 145);
            this.dateTimeNSinh.Name = "dateTimeNSinh";
            this.dateTimeNSinh.Size = new System.Drawing.Size(420, 32);
            this.dateTimeNSinh.TabIndex = 10;
            this.dateTimeNSinh.Value = new System.DateTime(2020, 7, 25, 0, 0, 0, 0);
            // 
            // btThoat
            // 
            this.btThoat.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThoat.Image = global::PS11905_BAODUONG_LAB3.Properties.Resources.Custom_Icon_Design_Pretty_Office_9_Edit_validated;
            this.btThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btThoat.Location = new System.Drawing.Point(659, 477);
            this.btThoat.Name = "btThoat";
            this.btThoat.Size = new System.Drawing.Size(106, 39);
            this.btThoat.TabIndex = 4;
            this.btThoat.Text = "    Thoát";
            this.btThoat.UseVisualStyleBackColor = true;
            // 
            // btXoa
            // 
            this.btXoa.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa.Image = global::PS11905_BAODUONG_LAB3.Properties.Resources.Awicons_Vista_Artistic_Delete;
            this.btXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btXoa.Location = new System.Drawing.Point(522, 477);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(108, 39);
            this.btXoa.TabIndex = 3;
            this.btXoa.Text = "    Xóa";
            this.btXoa.UseVisualStyleBackColor = true;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);
            // 
            // btLuu
            // 
            this.btLuu.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLuu.Image = global::PS11905_BAODUONG_LAB3.Properties.Resources.Custom_Icon_Design_Mono_General_1_Save;
            this.btLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btLuu.Location = new System.Drawing.Point(387, 477);
            this.btLuu.Name = "btLuu";
            this.btLuu.Size = new System.Drawing.Size(108, 39);
            this.btLuu.TabIndex = 2;
            this.btLuu.Text = "    Lưu";
            this.btLuu.UseVisualStyleBackColor = true;
            this.btLuu.Click += new System.EventHandler(this.btLuu_Click);
            // 
            // txtLop
            // 
            this.txtLop.Location = new System.Drawing.Point(249, 244);
            this.txtLop.Name = "txtLop";
            this.txtLop.Size = new System.Drawing.Size(420, 32);
            this.txtLop.TabIndex = 9;
            // 
            // Bai1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(819, 539);
            this.Controls.Add(this.btThoat);
            this.Controls.Add(this.btXoa);
            this.Controls.Add(this.btLuu);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Bai1";
            this.Text = "Bai1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Bai1_FormClosed);
            this.Load += new System.EventHandler(this.Bai1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDTB;
        private System.Windows.Forms.Label lbDiemTB;
        private System.Windows.Forms.Label lbLop;
        private System.Windows.Forms.TextBox txtDChi;
        private System.Windows.Forms.Label lbDiaChi;
        private System.Windows.Forms.Label lbNgaySinh;
        private System.Windows.Forms.TextBox txtTenHS;
        private System.Windows.Forms.Label lbTenHS;
        private System.Windows.Forms.TextBox txtMaHS;
        private System.Windows.Forms.Label lbMaHS;
        private System.Windows.Forms.Button btLuu;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btThoat;
        private System.Windows.Forms.DateTimePicker dateTimeNSinh;
        private System.Windows.Forms.TextBox txtLop;
    }
}