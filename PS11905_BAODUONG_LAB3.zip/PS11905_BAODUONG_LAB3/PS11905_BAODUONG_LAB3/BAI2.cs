﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PS11905_BAODUONG_LAB3
{
    public partial class BAI2 : Form
    {
        public BAI2()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void BAI2_FormClosed(object sender, FormClosedEventArgs e)
        {
            
            Application.Exit();
        }

        DataSet getAllHocSinh()
        {
            DataSet data = new DataSet();
            string query = "select * from HocSinh";
            using (SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-KMNS09Q;Initial Catalog=QLHocSinh;Integrated Security=True"))
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(data);
                conn.Close();
            }
            return data;

        }

        private void BAI2_Load(object sender, EventArgs e)
        {
            dateTimeNSinh.Format = DateTimePickerFormat.Custom;
            dateTimeNSinh.CustomFormat = "dd/MM/yyyy";
            dataGridView1.DataSource = getAllHocSinh().Tables[0];
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //DataGridViewRow row = new DataGridViewRow();
            //row = dataGridView1.Rows[e.RowIndex];

            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridView1.CurrentRow.Selected = true;
                txtMaHS.Text = dataGridView1.Rows[e.RowIndex].Cells["MaHS"].FormattedValue.ToString();
                txtTenHS.Text = dataGridView1.Rows[e.RowIndex].Cells["TenHS"].FormattedValue.ToString();
                txtDChi.Text = dataGridView1.Rows[e.RowIndex].Cells["DiaChi"].FormattedValue.ToString();
                txtDTB.Text = dataGridView1.Rows[e.RowIndex].Cells["DTB"].FormattedValue.ToString();
                txtLop.Text = dataGridView1.Rows[e.RowIndex].Cells["MaLop"].FormattedValue.ToString();
                dateTimeNSinh.Text = dataGridView1.Rows[e.RowIndex].Cells["NgaySinh"].Value.ToString();
                
            }
        }

        private void btLuu_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KMNS09Q;Initial Catalog=QLHocSinh;Integrated Security=True"))
            {
                con.Open();
                try
                {
                    // Query insert
                    string query = "update HocSinh set MaHS = @MaHS,TenHS = @TenHS,NgaySinh = @NgaySinh,DiaChi = @DiaChi,DTB = @DTB, MaLop = @MaLop where MaHS = @id";
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = query;
                    var mahs1 = dataGridView1.CurrentRow.Cells["MaHS"].FormattedValue.ToString();
                    cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = mahs1;
                    // Tạo một đối tượng Parameter.
                    cmd.Parameters.Add("@MaHS", SqlDbType.VarChar).Value = txtMaHS.Text;
                    cmd.Parameters.Add("@TenHS", SqlDbType.NVarChar).Value = txtTenHS.Text;
                    cmd.Parameters.Add("@NgaySinh", SqlDbType.Date).Value = dateTimeNSinh.Value.ToString();
                    cmd.Parameters.Add("@DiaChi", SqlDbType.VarChar).Value = txtDChi.Text;
                    cmd.Parameters.Add("@DTB", SqlDbType.Float).Value = txtDTB.Text;
                    cmd.Parameters.Add("@MaLop", SqlDbType.VarChar).Value = txtLop.Text;

                    cmd.ExecuteNonQuery();
                    
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }
                
                dataGridView1.DataSource = getAllHocSinh().Tables[0];
            }
            }

        private void btXoa_Click(object sender, EventArgs e)
        {

            DialogResult info = MessageBox.Show("Bạn có muốn xóa sinh viên này không ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (info == DialogResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KMNS09Q;Initial Catalog=QLHocSinh;Integrated Security=True"))
                {
                    con.Open();
                    try
                    {
                        // Query insert
                        string query = "delete from HocSinh where MaHS = @MaHS";
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandText = query;

                        // Tạo một đối tượng Parameter.
                        cmd.Parameters.Add("@MaHS", SqlDbType.VarChar).Value = txtMaHS.Text;
                        cmd.Parameters.Add("@TenHS", SqlDbType.NVarChar).Value = txtTenHS.Text;
                        cmd.Parameters.Add("@NgaySinh", SqlDbType.Date).Value = dateTimeNSinh.Value.ToString();
                        cmd.Parameters.Add("@DiaChi", SqlDbType.VarChar).Value = txtDChi.Text;
                        cmd.Parameters.Add("@DTB", SqlDbType.Float).Value = txtDTB.Text;
                        cmd.Parameters.Add("@MaLop", SqlDbType.VarChar).Value = txtLop.Text;

                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                    dataGridView1.DataSource = getAllHocSinh().Tables[0];
                }
             }
                    else
                    {
                        return;
                    }
            
                
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
