﻿namespace PS11905_BAODUONG_LAB3
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbMenu = new System.Windows.Forms.Label();
            this.lbBai1 = new System.Windows.Forms.Label();
            this.lbBai2 = new System.Windows.Forms.Label();
            this.hinhBai2 = new System.Windows.Forms.PictureBox();
            this.hinhBai1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.hinhBai2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hinhBai1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbMenu
            // 
            this.lbMenu.AutoSize = true;
            this.lbMenu.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMenu.ForeColor = System.Drawing.Color.Red;
            this.lbMenu.Location = new System.Drawing.Point(188, 24);
            this.lbMenu.Name = "lbMenu";
            this.lbMenu.Size = new System.Drawing.Size(363, 73);
            this.lbMenu.TabIndex = 2;
            this.lbMenu.Text = "Form Menu";
            // 
            // lbBai1
            // 
            this.lbBai1.AutoSize = true;
            this.lbBai1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBai1.ForeColor = System.Drawing.Color.Blue;
            this.lbBai1.Location = new System.Drawing.Point(170, 286);
            this.lbBai1.Name = "lbBai1";
            this.lbBai1.Size = new System.Drawing.Size(93, 37);
            this.lbBai1.TabIndex = 3;
            this.lbBai1.Text = "Bài 1";
            // 
            // lbBai2
            // 
            this.lbBai2.AutoSize = true;
            this.lbBai2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBai2.ForeColor = System.Drawing.Color.Blue;
            this.lbBai2.Location = new System.Drawing.Point(456, 286);
            this.lbBai2.Name = "lbBai2";
            this.lbBai2.Size = new System.Drawing.Size(95, 37);
            this.lbBai2.TabIndex = 4;
            this.lbBai2.Text = "Bài 2";
            // 
            // hinhBai2
            // 
            this.hinhBai2.BackgroundImage = global::PS11905_BAODUONG_LAB3.Properties.Resources.Number_2_icon;
            this.hinhBai2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hinhBai2.Location = new System.Drawing.Point(434, 161);
            this.hinhBai2.Name = "hinhBai2";
            this.hinhBai2.Size = new System.Drawing.Size(143, 109);
            this.hinhBai2.TabIndex = 1;
            this.hinhBai2.TabStop = false;
            this.hinhBai2.Click += new System.EventHandler(this.hinhBai2_Click);
            // 
            // hinhBai1
            // 
            this.hinhBai1.BackgroundImage = global::PS11905_BAODUONG_LAB3.Properties.Resources.Number_1_icon;
            this.hinhBai1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hinhBai1.Location = new System.Drawing.Point(143, 161);
            this.hinhBai1.Name = "hinhBai1";
            this.hinhBai1.Size = new System.Drawing.Size(143, 109);
            this.hinhBai1.TabIndex = 0;
            this.hinhBai1.TabStop = false;
            this.hinhBai1.Click += new System.EventHandler(this.hinhBai1_Click);
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(740, 450);
            this.Controls.Add(this.lbBai2);
            this.Controls.Add(this.lbBai1);
            this.Controls.Add(this.lbMenu);
            this.Controls.Add(this.hinhBai2);
            this.Controls.Add(this.hinhBai1);
            this.Name = "FormMenu";
            this.Text = "Menu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMenu_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.hinhBai2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hinhBai1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox hinhBai1;
        private System.Windows.Forms.PictureBox hinhBai2;
        private System.Windows.Forms.Label lbMenu;
        private System.Windows.Forms.Label lbBai1;
        private System.Windows.Forms.Label lbBai2;
    }
}

